import React from 'react';
import {Sbanner,ServiceC} from "../component";

const Services = () => {
  return (
    <>
    <Sbanner/>
    <ServiceC/>
    </>
  )
}

export default Services