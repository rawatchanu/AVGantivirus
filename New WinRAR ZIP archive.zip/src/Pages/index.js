export {default as Home} from "./Home";
export {default as AboutUs} from "./AboutUs";
export {default as Blog} from "./Blog";
export {default as Services} from "./Services";
export {default as Contact} from "./Contact";
