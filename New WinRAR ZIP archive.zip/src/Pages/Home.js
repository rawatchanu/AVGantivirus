import React from 'react';
import {Hbanner,About,Services,Serbanner,Post} from "../component";
const Home = () => {
  return (
   <>
        <Hbanner/>
        <About/>
        <Services/>
        <Serbanner/>
        <Post/>
   </>
  )
}

export default Home