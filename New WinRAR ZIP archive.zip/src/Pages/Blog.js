import React from 'react';
import {Bbanner,BlogC} from "../component";

const Blog = () => {
  return (
   <>
    <Bbanner/>
    <BlogC/>
   </>
  )
}

export default Blog