import React from 'react';
import {ContactUs} from "../component";

const Contact = () => {
  return (
    <>
      <ContactUs/>
    </>
  )
}

export default Contact