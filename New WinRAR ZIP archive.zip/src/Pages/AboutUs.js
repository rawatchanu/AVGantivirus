import React from 'react';
import {Abanner,About} from "../component";

const AboutUs = () => {
  return (
    <>
      <Abanner/>
      <About/>
    </>
  )
}

export default AboutUs